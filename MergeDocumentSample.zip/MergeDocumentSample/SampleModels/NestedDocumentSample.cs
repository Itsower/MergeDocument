﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Reference MergeDocument
using MergeDocument.Model.BaseObject;
using MergeDocument.Model.Interface;

namespace MergeMocumentSampleCode.SampleModels
{
    // Template Class, must inheritance TemplateDataBase class
    public class NestedDocumentSample : TemplateDataBase
    {
        [BindField]
        public string OrderName { get; set; }

        // Block Repeater Property, must Add BlockRepeater attribute
        // Use collections as type of BlockRepeater Property
        [BlockRepeater]
        public List<ProductDescription> ProductDescriptions { get; set; }

        // Table Repeater Property, must Add Repeater attribute
        // Use collections as type of Repeater Property
        [TableRepeater]
        public List<OrderDetail> OrderDetails { get; set; }
    }

    // Nested Repeater
    public class ProductDescription : TemplateDataBase
    {
        [BindField]
        public string DescriptionContent { get; set; }
    }

    // Nested Repeater
    public class OrderDetail : TemplateDataBase
    {
        [BindField]
        public string UnitPrice { get; set; }

        [BindField]
        public string Quantity { get; set; }

        [BindField]
        public string Discount { get; set; }

        [BindField]
        public string Customer { get; set; }

        [BindField]
        public string ExtendedPrice { get; set; }
    }
}