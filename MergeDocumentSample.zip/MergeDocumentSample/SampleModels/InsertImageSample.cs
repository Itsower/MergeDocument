﻿using MergeDocument.Model.BaseObject;
using MergeDocument.Model.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MergeMocumentSampleCode.SampleModels
{
    // Template Class, must inheritance TemplateDataBase class
    public class InsertImageSample : TemplateDataBase
    {
        // Add Image Attribute for Image Content
        [Image]
        public string ImageContent { get; set; }
    }
}