﻿using MergeDocument.Model.BaseObject;
using MergeDocument.Model.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MergeMocumentSampleCode.SampleModels
{
    // Template Class, must inheritance TemplateDataBase class
    public class InsertImageNestedSample : TemplateDataBase
    {
        [BindField]
        public string ShipName { get; set; }

        // Block Repeater Property, must Add BlockRepeater attribute
        // Use collections as type of BlockRepeater Property
        [BlockRepeater]
        public List<ShipDescription> ShipDescriptions { get; set; }

        // Table Repeater Property, must Add Repeater attribute
        // Use collections as type of Repeater Property
        [TableRepeater]
        public List<ShippingDetail> ShippingDetails { get; set; }
    }

    // Nested Repeater
    public class ShipDescription : TemplateDataBase
    {
        [BindField]
        public string ShipDescriptionContent { get; set; }

        [Image]
        public string ShipContentImage { get; set; }
    }

    // Nested Repeater
    public class ShippingDetail : TemplateDataBase
    {
        [BindField]
        public string ShippingPrice { get; set; }

        [BindField]
        public string ShippingQuantity { get; set; }

        [BindField]
        public string ShippingDiscount { get; set; }

        [BindField]
        public string ShipToCustomer { get; set; }

        [BindField]
        public string ShippingExtendedPrice { get; set; }

        // Add Image Attribute for Image Content
        [Image]
        public string ShippingProductImage { get; set; }
    }
}
