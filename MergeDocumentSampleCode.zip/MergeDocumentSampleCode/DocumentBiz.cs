﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MergeDocument.Biz;
using MergeDocument.Model.Interface;
using MergeMocumentSampleCode.SampleModels;
using MergeDocument.Common;

namespace MergeMocumentSampleCode
{
    public class DocumentBiz
    {
        /// <summary>
        /// Word Block Repeat
        /// </summary>
        public void BlockRepeatSample()
        {
            string output = Path.Combine(@"D:\", $"{DateTime.Now:yyyyMMddHHmmss}.docx");

            List<TemplateDataBase> data = new List<TemplateDataBase>
            {
                new BlockRepeat { Text = "Write document content with flexible custom model structure." },
                new BlockRepeat { Text = "Generate document content with repeatable template, including World Block and Table." },
                new BlockRepeat { Text = "Support .Net Framework development, and Microsoft World Developer template." }
            };

            var wordXmlBiz = new WordXMLBiz(data);
            wordXmlBiz.MergeFile(@"D:\BlockRepeatSample.docx", output);
            Console.WriteLine($@"File {output} generated successfully");
        }

        /// <summary>
        /// Word Table Repeat
        /// </summary>
        public void TableRepeatSample()
        {
            string output = Path.Combine(@"D:\", $"{DateTime.Now:yyyyMMddHHmmss}.docx");

            List<TemplateDataBase> data = new List<TemplateDataBase>
            {
                new TableRepeatSample
                {
                    Name = "Login Button",
                    InputTypeName = "Button",
                    Descriptions = "Login Button Descriptions"
                },
                new TableRepeatSample
                {
                    Name = "Cancel Button",
                    InputTypeName = "Button",
                    Descriptions = "Cancel Button Descriptions"
                },
                new TableRepeatSample
                {
                    Name = "Account Input",
                    InputTypeName = "TextBox",
                    Descriptions = "Account Input Descriptions"
                },
                new TableRepeatSample
                {
                    Name = "Password Input",
                    InputTypeName = "TextBox",
                    Descriptions = "Password Input Descriptions"
                },
            };

            var wordXmlBiz = new WordXMLBiz(data, SystemEnum.RepeaterType.TableRow);
            wordXmlBiz.MergeFile(@"D:\TableRepeatSample.docx", output);
            Console.WriteLine($@"File {output} generated successfully");
        }

        public void NestedDocumentSample()
        {
            string output = Path.Combine(@"D:\", $"{DateTime.Now:yyyyMMddHHmmss}.docx");

            List<TemplateDataBase> data = new List<TemplateDataBase>
            {
                new NestedDocumentSample()
                {
                   OrderName = "Pencils",
                   ProductDescriptions = new List<ProductDescription>
                   {
                       new ProductDescription
                       {
                           DescriptionContent ="Pencil DescriptionContent"
                       },
                       new ProductDescription
                       {
                           DescriptionContent ="Pencil Price"
                       },
                       new ProductDescription
                       {
                           DescriptionContent ="Pencil Supplier"
                       },
                   },
                   OrderDetails = new List<OrderDetail>
                   {
                       new OrderDetail
                       {
                           UnitPrice = "10",
                           Quantity = "100",
                           Discount = "0",
                           Customer = "○○ Customer",
                           ExtendedPrice = "0",
                       },
                       new OrderDetail
                       {
                           UnitPrice = "10",
                           Quantity = "500",
                           Discount = "0",
                           Customer = "○○ Customer1",
                           ExtendedPrice = "0",
                       },
                       new OrderDetail
                       {
                           UnitPrice = "10",
                           Quantity = "300",
                           Discount = "0",
                           Customer = "○○ Customer2",
                           ExtendedPrice = "0",
                       },
                   }
                },
                new NestedDocumentSample()
                {
                   OrderName = "Notebooks",
                   ProductDescriptions = new List<ProductDescription>
                   {
                       new ProductDescription
                       {
                           DescriptionContent ="Notebooks DescriptionContent"
                       },
                       new ProductDescription
                       {
                           DescriptionContent ="Notebooks Price"
                       },
                       new ProductDescription
                       {
                           DescriptionContent ="Notebooks Supplier"
                       },
                   },
                   OrderDetails = new List<OrderDetail>
                   {
                       new OrderDetail
                       {
                           UnitPrice = "40",
                           Quantity = "100",
                           Discount = "0",
                           Customer = "○○ Customer",
                           ExtendedPrice = "0",
                       },
                       new OrderDetail
                       {
                           UnitPrice = "40",
                           Quantity = "100",
                           Discount = "0",
                           Customer = "○○ Customer1",
                           ExtendedPrice = "0",
                       },
                       new OrderDetail
                       {
                           UnitPrice = "40",
                           Quantity = "100",
                           Discount = "0",
                           Customer = "○○ Customer2",
                           ExtendedPrice = "0",
                       },
                   }
                },
                new NestedDocumentSample()
                {
                   OrderName = "Erasers",
                   ProductDescriptions = new List<ProductDescription>
                   {
                       new ProductDescription
                       {
                           DescriptionContent ="Erasers DescriptionContent"
                       },
                       new ProductDescription
                       {
                           DescriptionContent ="Erasers Price"
                       },
                       new ProductDescription
                       {
                           DescriptionContent ="Erasers Supplier"
                       },
                   },
                   OrderDetails = new List<OrderDetail>
                   {
                       new OrderDetail
                       {
                           UnitPrice = "12",
                           Quantity = "100",
                           Discount = "0",
                           Customer = "○○ Customer",
                           ExtendedPrice = "0",
                       },
                       new OrderDetail
                       {
                           UnitPrice = "12",
                           Quantity = "100",
                           Discount = "0",
                           Customer = "○○ Customer1",
                           ExtendedPrice = "0",
                       },
                       new OrderDetail
                       {
                           UnitPrice = "12",
                           Quantity = "100",
                           Discount = "0",
                           Customer = "○○ Customer2",
                           ExtendedPrice = "0",
                       },
                   }
                },
            };

            var wordXmlBiz = new WordXMLBiz(data);
            wordXmlBiz.MergeFile(@"D:\NestedDocumentSample.docx", output);
            Console.WriteLine($@"File {output} generated successfully");
        }
    }
}