﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MergeMocumentSampleCode
{
    public class Program
    {
        static void Main(string[] args)
        {
            DocumentBiz dBiz = new DocumentBiz();
            //dBiz.BlockRepeatSample();
            //dBiz.TableRepeatSample();
            dBiz.NestedDocumentSample();
        }
    }
}
